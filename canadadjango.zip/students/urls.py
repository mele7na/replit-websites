from django.urls import path
from . import views

urlpatterns = [
    path('ogrenci/', views.students, name='students'),
    path('student/', views.students, name='students'),
    path('students/', views.studentslist, name='studentslist')

]