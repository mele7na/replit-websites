from django.http import HttpResponse

def students(request):
    return HttpResponse("Students bölümü")


# Create your views here.
from django.template import loader # html sayfa döndürürken


def studentslist(request):
    studentsliste = students.objects.all()
    template = loader.get_template('studentslistesi.html')
    context ={
        'studentsliste' : studentsliste,
    }
    return HttpResponse(template.render(context, request))

def student(request):
    template = loader.get_template('index1.html')
    return HttpResponse(template.render()) 

