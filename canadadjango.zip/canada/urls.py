from django.urls import path
from . import views

urlpatterns = [
    path('canada/', views.canada, name='canada'),
    path('kanada/', views.canada, name='canada'),
]
