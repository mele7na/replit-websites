from django.http import HttpResponse

def canada(request):
    return HttpResponse("canada bölümü")

