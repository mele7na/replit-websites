#from django.urls import path
#from . import views

#urlpatterns = [
#   path('', views.anasayfa, name='anasayfa'),
#    path('ana/', views.anasayfa, name='anasayfa'),
#    path('home/', views.anasayfa, name='anasayfa'),
#]


# anasayfa app te urls.py diye bir dosya oluştur, bunları ekle
from django.urls import path
from . import views

urlpatterns = [
    path('home/', views.anasayfa, name='anasayfa'),
    path('anasayfa/', views.anasayfa, name='anasayfa'),
    path('ana/', views.anasayfa, name='anasayfa'),
    path('', views.master, name='master'),

]


# from django.urls import path
# from . import views

# urlpatterns = [
#     path('ogrenci/', views.ogrenci, name='ogrenci'),
#     path('student/', views.ogrenci, name='ogrenci'),

# ]